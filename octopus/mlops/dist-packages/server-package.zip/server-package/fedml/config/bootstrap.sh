#!/bin/bash

# pip install fedml==0.7.15
#pip install --upgrade fedml
