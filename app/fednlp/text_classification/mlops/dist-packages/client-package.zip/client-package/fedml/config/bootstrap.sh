pip install -r ./../requirements.txt
bash ../data/download_data.sh
bash ../data/download_partition.sh