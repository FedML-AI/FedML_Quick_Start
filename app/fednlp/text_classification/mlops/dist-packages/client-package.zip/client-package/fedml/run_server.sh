#!/usr/bin/env bash
python torch_main.py --cf config/fedml_config.yaml --rank 0 --role server
